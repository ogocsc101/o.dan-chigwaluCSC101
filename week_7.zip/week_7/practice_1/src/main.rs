fn my_grade(){
    
    // functio body
    println!("Greetings from function my_grade!");
}

fn main(){
    
    //callig a function
    my_grade();
}
